import Todos from './Todos/Todos';
const App = () => {
  return <Todos />;
};

export default App;
